# ResBot JPM

ResBot JPM adalah bot WhatsApp yang di gunakan untuk pushkontak atau broadcast ke banyak grub. Dikembangkan menggunakan JavaScript, bot ini dirancang untuk memberikan pengalaman yang lebih mudah dan efisien melalui platform WhatsApp.

## Fitur Utama

- Listgc
- pushkontak
- jpm
- ping

## Instalasi

1. **Klon repositori ini**
   ```bash
   git clone https://github.com/autoresbot/resbot-jpm.git
   cd resbot-ai
   ```
