/*
⚠️ PERINGATAN:
Script ini **TIDAK BOLEH DIPERJUALBELIKAN** dalam bentuk apa pun!

╔══════════════════════════════════════════════╗
║                🛠️ INFORMASI SCRIPT           ║
╠══════════════════════════════════════════════╣
║ 📦 Version   : 1.3
║ 👨‍💻 Developer  : Azhari Creative              ║
║ 🌐 Website    : https://autoresbot.com       ║
║ 💻 GitHub     : github.com/autoresbot/resbot-jpm
╚══════════════════════════════════════════════╝

📌 Mulai 11 April 2025,
Script **Autoresbot** resmi menjadi **Open Source** dan dapat digunakan secara gratis:
🔗 https://autoresbot.com
*/

const numberAllowed = ['6285246154386','62xxxxxxxxx']; // Nomor yang diizinkan untuk chat ke bot, tambahkan kalau diperlukan

global.prefix = ['.', '#']; // Daftar prefix

global.jeda = 5000; // 5 detik jeda pengiriman untuk pushkontak atau broadcast

global.name_script = 'Script Jpm';

global.version = '1.3';

module.exports = { numberAllowed };